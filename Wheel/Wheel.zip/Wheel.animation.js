import { gsap } from 'gsap'

/**
 * Запуск вращения колеса по ТЗ:
 * - плавно
 * - физически правдоподобно
 * - 4–6 секунд
 * - ease-out замедление
 * - небольшой realistic bounce-back до 5°
 *
 * wheelRef должен указывать на DOM-обёртку (div), а не на SVG <g>.
 */
export const spinWheel = (wheelRef, targetRotation, onComplete) => {
  const el = wheelRef?.current
  if (!el) return

  // Жёстко убиваем предыдущие анимации, чтобы не было "рывков" от наложения tween'ов
  gsap.killTweensOf(el)

  // Длительность строго 4–6 сек
  const duration = 4 + Math.random() * 2 // [4..6)
  // Откат строго до 5 градусов
  const bounceBackDeg = 3 + Math.random() * 2 // [3..5)

  // Для мобилок: просим браузер держать слой в GPU-композитинге
  gsap.set(el, {
    willChange: 'transform',
    force3D: true,
    transformOrigin: '50% 50%'
  })

  // Чтобы bounce-back выглядел реалистично: чуть "переехали" цель и вернулись
  const overshoot = targetRotation + bounceBackDeg

  const tl = gsap.timeline({
    defaults: { overwrite: true },
    onComplete: () => {
      // Снимаем will-change, чтобы не держать лишний слой всегда
      gsap.set(el, { willChange: 'auto' })
      if (typeof onComplete === 'function') onComplete()
    }
  })

  // Основное вращение: плавный ease-out (замедление в конце)
  tl.to(el, {
    rotation: overshoot,
    duration,
    ease: 'power4.out'
  })

  // Мягкий откат назад к точной цели (не больше 5°)
  tl.to(el, {
    rotation: targetRotation,
    duration: 0.35,
    ease: 'power2.out'
  })

  return tl
}
