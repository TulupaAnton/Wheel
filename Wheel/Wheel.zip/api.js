export const requestSpinResult = async () => {
  return { winnerIndex: 0 }
}
