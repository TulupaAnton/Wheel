/**
 * Возвращает целевую rotation (в градусах), которая:
 * - делает 5–7 полных оборотов
 * - останавливается в центре winnerIndex сектора под стрелкой
 *
 * Важно: winnerIndex — индекс сектора (0..totalSectors-1)
 * totalSectors — количество секторов
 * currentRotation — текущий угол (в градусах), который уже установлен на DOM-обёртку
 */
export const getTargetRotation = (
  winnerIndex,
  totalSectors,
  currentRotation
) => {
  const angleStep = 360 / totalSectors

  // Центр сектора (чтобы стрелка указывала ровно на сектор)
  const winnerCenterAngle = winnerIndex * angleStep + angleStep / 2

  // 5–7 полных оборотов по ТЗ
  const fullSpins = 5 + Math.floor(Math.random() * 3) // 5, 6 или 7
  const spinsRotation = fullSpins * 360

  /**
   * Если твоя стрелка находится сверху (12 часов), а твой нулевой угол колеса
   * также ориентирован на верх — тогда формула ниже корректна.
   *
   * Если в твоей разметке есть стартовый сдвиг (-angleStep/2 и т.п.),
   * currentRotation уже учитывает этот оффсет — поэтому здесь он не нужен отдельно.
   */

  // Двигаемся вперёд на spinsRotation и "докручиваем" так, чтобы winnerCenterAngle попал под стрелку
  const target = currentRotation + spinsRotation - winnerCenterAngle

  return target
}
